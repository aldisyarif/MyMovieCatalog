package com.bisa.submissionone.ui.movies

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.bisa.submissionone.data.CatalogEntity
import com.bisa.submissionone.data.source.CatalogRepository

class MovieViewModel(private val catalogRepository: CatalogRepository): ViewModel() {

    fun getMovies(): LiveData<List<CatalogEntity>> = catalogRepository.getListMovies()
}