package com.bisa.submissionone.data

data class CatalogEntity(
    var dataId: String,
    var imagePoster: String,
    var title: String,
)
