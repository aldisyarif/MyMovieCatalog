package com.bisa.submissionone.data.source.remote

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.bisa.submissionone.api.ApiConfig
import com.bisa.submissionone.api.ConfigNetwork.API_KEY
import com.bisa.submissionone.api.ConfigNetwork.LANGUAGE
import com.bisa.submissionone.api.ConfigNetwork.PAGE
import com.bisa.submissionone.data.source.remote.response.*
import com.bisa.submissionone.utils.EspressoIdlingResource
import org.json.JSONException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RemoteDataSource{

    companion object{

        const val TAG = "RemoteDataSource"
        private const val SERVICE_LATENCY_IN_MILLIS: Long = 1000

        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(): RemoteDataSource =
            instance ?: synchronized(this){
                instance ?: RemoteDataSource().apply { instance = this }
            }

    }

    private val handler = Handler(Looper.getMainLooper())


    fun getListMovies(callback: LoadListMoviesCallback){

        EspressoIdlingResource.increment()
        handler.postDelayed({

            val client = ApiConfig.getApiService().getMovies(API_KEY, LANGUAGE, PAGE)

            try {
                client.enqueue(object : Callback<MoviesResponse> {
                    override fun onResponse(
                        call: Call<MoviesResponse>,
                        response: Response<MoviesResponse>
                    ) {

                        if (response.isSuccessful){
                            Log.d(TAG, " Success : ${response.body()?.results?.get(0)?.title}")

                            callback.onListMoviesReceived(response.body()?.results!!)

                            EspressoIdlingResource.decrement()

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }

                    }

                    override fun onFailure(call: Call<MoviesResponse>, t: Throwable) {
                        Log.e(TAG, "onFailure: ${t.message.toString()}")
                    }

                })

            }catch (e: JSONException){
                e.printStackTrace()
            }



        }, SERVICE_LATENCY_IN_MILLIS)

    }

    fun getListTvShows(callback: LoadListTvShowsCallback) {

        EspressoIdlingResource.increment()
        handler.postDelayed({
            val client = ApiConfig.getApiService().getTvShows(API_KEY, LANGUAGE, PAGE)

            try {
                client.enqueue(object : Callback<TvShowsResponse> {
                    override fun onResponse(
                        call: Call<TvShowsResponse>,
                        response: Response<TvShowsResponse>
                    ) {
                        if (response.isSuccessful){
                            Log.d(TAG, " Success : ${response.body()?.results?.get(0)?.name}")

                            callback.onListTvShowsReceived(response.body()?.results!!)

                            EspressoIdlingResource.decrement()

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }

                    override fun onFailure(call: Call<TvShowsResponse>, t: Throwable) {
                        Log.e(TAG, "onFailure: ${t.message.toString()}")
                    }

                })
            } catch (e: JSONException){
                e.printStackTrace()
            }

        }, SERVICE_LATENCY_IN_MILLIS)

    }



    fun getDetailCatalogMovie(movieId: String, callback: LoadDetailMovieCatalogCallback){

        EspressoIdlingResource.increment()
        handler.postDelayed({

            val client = ApiConfig.getApiService().getDetailMovie(movieId, API_KEY, LANGUAGE)

            try {
                client.enqueue(object : Callback<DetailCatalogMovieResponse> {
                    override fun onResponse(
                        call: Call<DetailCatalogMovieResponse>,
                        response: Response<DetailCatalogMovieResponse>
                    ) {
                        if (response.isSuccessful){

                            Log.d(TAG, " Success : ${response.body()?.title}")
                            callback.onDetailMovieCatalogReceived(response.body()!!)

                            EspressoIdlingResource.decrement()

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }

                    override fun onFailure(call: Call<DetailCatalogMovieResponse>, t: Throwable) {
                        Log.e(TAG, "onFailure: ${t.message.toString()}")
                    }

                })
            } catch (e: JSONException){
                e.printStackTrace()
            }



        }, SERVICE_LATENCY_IN_MILLIS)

    }

    fun getDetailCatalogTvShow(tvShowId: String, callback: LoadDetailTvShowCatalogCallback){

        EspressoIdlingResource.increment()
        handler.postDelayed({

            val client = ApiConfig.getApiService().getDetailTvShow(tvShowId, API_KEY, LANGUAGE)

            try {
                client.enqueue(object : Callback<DetailCatalogTvResponse>{
                    override fun onResponse(
                        call: Call<DetailCatalogTvResponse>,
                        response: Response<DetailCatalogTvResponse>
                    ) {
                        if (response.isSuccessful){

                            Log.d(TAG, " Success : ${response.body()?.name}")
                            callback.onDetailTvShowCatalogReceived(response.body()!!)

                            EspressoIdlingResource.decrement()

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }

                    override fun onFailure(call: Call<DetailCatalogTvResponse>, t: Throwable) {
                        Log.e(TAG, "onFailure: ${t.message.toString()}")
                    }

                })
            } catch (e: JSONException){
                e.printStackTrace()
            }



        }, SERVICE_LATENCY_IN_MILLIS)

    }

    fun getCreditMovieActor(movieId: String, callback: LoadCreditMovieActorCallback){

        handler.postDelayed({

            val client = ApiConfig.getApiService().getCreditMovie(movieId, API_KEY, LANGUAGE)

            try {
                client.enqueue(object : Callback<CreditMovieActorResponse>{
                    override fun onResponse(
                        call: Call<CreditMovieActorResponse>,
                        response: Response<CreditMovieActorResponse>
                    ) {
                        if (response.isSuccessful){

                            Log.d(TAG, " Success : ${response.body()?.castMovie!![0].name}")

                            callback.onCreditMovieActorReceived(response.body()?.castMovie!!)

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }

                    override fun onFailure(call: Call<CreditMovieActorResponse>, t: Throwable) {
                        Log.e(TAG, "onFailuree: ${t.message.toString()}")
                    }
                })

            } catch (e: JSONException){
                e.printStackTrace()
            }

        }, SERVICE_LATENCY_IN_MILLIS)

    }

    fun getCreditTvShowActor(tvId: String, callback: LoadCreditTvShowActorCallback){

        handler.postDelayed({

            val client = ApiConfig.getApiService().getCreditTvShow(tvId, API_KEY, LANGUAGE)

            try{
                client.enqueue(object : Callback<CreditTvShowActorResponse>{
                    override fun onResponse(
                        call: Call<CreditTvShowActorResponse>,
                        response: Response<CreditTvShowActorResponse>
                    ) {
                        if (response.isSuccessful){

                            Log.d(TAG, " Success : ${response.body()?.cast!![0].name}")

                            callback.onCreditTvShowActorReceived(response.body()?.cast!!)

                        }else{
                            Log.e(TAG, "onFailure: ${response.message()}")
                        }
                    }

                    override fun onFailure(call: Call<CreditTvShowActorResponse>, t: Throwable) {
                        Log.e(TAG, "onFailuree: ${t.message.toString()}")
                    }

                })

            } catch (e: JSONException){
                e.printStackTrace()
            }

        }, SERVICE_LATENCY_IN_MILLIS)

    }


    interface LoadListMoviesCallback{
        fun onListMoviesReceived(moviesResponse: List<ResultsMovieItem>)
    }

    interface LoadListTvShowsCallback{
        fun onListTvShowsReceived(tvShowsResponse: List<ResultsTvShowItem>)
    }

    interface LoadDetailMovieCatalogCallback{
        fun onDetailMovieCatalogReceived(detailCatalogMovie: DetailCatalogMovieResponse)
    }

    interface LoadDetailTvShowCatalogCallback{
        fun onDetailTvShowCatalogReceived(detailCatalogTv: DetailCatalogTvResponse)
    }

    interface LoadCreditMovieActorCallback{
        fun onCreditMovieActorReceived(creditMovieActorResponse: List<CastMovieItem>)
    }

    interface LoadCreditTvShowActorCallback{
        fun onCreditTvShowActorReceived(creditTvActorResponse: List<CastTvItem>)
    }
}