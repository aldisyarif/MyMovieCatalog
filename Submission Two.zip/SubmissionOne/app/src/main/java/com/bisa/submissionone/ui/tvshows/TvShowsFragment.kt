package com.bisa.submissionone.ui.tvshows

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.bisa.submissionone.data.CatalogEntity
import com.bisa.submissionone.databinding.FragmentTvShowsBinding
import com.bisa.submissionone.ui.detail.DetailMovieActivity
import com.bisa.submissionone.viewmodel.ViewModelFactory


class TvShowsFragment : Fragment() {

    private lateinit var binding: FragmentTvShowsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentTvShowsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity != null){
            showListTvShow()
        }
    }

    private fun showListTvShow() {

        val factory = ViewModelFactory.getInstance()
        val viewModel = ViewModelProvider(this, factory)[TvShowViewModel::class.java]

        binding.loadingTvShow.visibility = View.VISIBLE

        val tvShowAdapter = TvShowAdapter()
        viewModel.getTvShows().observe(viewLifecycleOwner, { tvShows ->

            binding.loadingTvShow.visibility = View.GONE

            tvShowAdapter.setTvShows(tvShows)
            tvShowAdapter.notifyDataSetChanged()
        })



        with(binding.rvTvShow){
            layoutManager = GridLayoutManager(context, 2)
            setHasFixedSize(true)
            adapter = tvShowAdapter
        }

        tvShowAdapter.setOnItemClickCallback(object : TvShowAdapter.OnItemClickCallback{
            override fun onItemClicked(movie: CatalogEntity) {
                val intent = Intent(context, DetailMovieActivity::class.java)
                intent.putExtra(DetailMovieActivity.EXTRA_ID, movie.dataId)
                intent.putExtra(DetailMovieActivity.EXTRA_TYPE, DetailMovieActivity.TYPE_TV_SHOW)
                startActivity(intent)
            }

        })

    }


}