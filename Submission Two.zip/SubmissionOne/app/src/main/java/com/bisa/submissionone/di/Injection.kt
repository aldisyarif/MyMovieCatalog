package com.bisa.submissionone.di

import com.bisa.submissionone.data.source.CatalogRepository
import com.bisa.submissionone.data.source.remote.RemoteDataSource

object Injection {

    fun provideRepository(): CatalogRepository {

        val remoteDataSource = RemoteDataSource.getInstance()

        return CatalogRepository.getInstance(remoteDataSource)
    }
}