package com.bisa.submissionone.ui.tvshows

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.bisa.submissionone.data.CatalogEntity
import com.bisa.submissionone.data.source.CatalogRepository

class TvShowViewModel(private val catalogRepository: CatalogRepository) : ViewModel() {

    fun getTvShows() : LiveData<List<CatalogEntity>> = catalogRepository.getListTvShows()
}