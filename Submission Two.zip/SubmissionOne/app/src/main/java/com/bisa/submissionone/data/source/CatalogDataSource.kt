package com.bisa.submissionone.data.source

import androidx.lifecycle.LiveData
import com.bisa.submissionone.data.*

interface CatalogDataSource {

    fun getListMovies(): LiveData<List<CatalogEntity>>

    fun getListTvShows(): LiveData<List<CatalogEntity>>

    fun getDetailCatalogMovie(movieId: String): LiveData<DetailCatalogEntity>

    fun getDetailCatalogTvShow(tvId: String): LiveData<DetailCatalogEntity>

    fun getCreditMovieActor(movieId: String): LiveData<List<ActorEntity>>

    fun getCreditTvShowActor(tvId: String): LiveData<List<ActorEntity>>
}