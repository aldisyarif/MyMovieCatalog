package com.bisa.submissionone.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.bisa.submissionone.data.ActorEntity
import com.bisa.submissionone.data.DetailCatalogEntity
import com.bisa.submissionone.data.source.CatalogRepository

class DetailViewModel(private val catalogRepository: CatalogRepository): ViewModel() {

    private lateinit var dataIdMovie: String
    private lateinit var dataIdTvShow: String

    fun setSelectedMovie(id: String){
        this.dataIdMovie = id
    }

    fun setSelectedTvShow(id: String){
        this.dataIdTvShow = id
    }


    fun getContentMovie(): LiveData<DetailCatalogEntity> = catalogRepository.getDetailCatalogMovie(dataIdMovie)

    fun getContentTvShow(): LiveData<DetailCatalogEntity> = catalogRepository.getDetailCatalogTvShow(dataIdTvShow)

    fun getActorMovie(): LiveData<List<ActorEntity>> = catalogRepository.getCreditMovieActor(dataIdMovie)

    fun getActorTvShow(): LiveData<List<ActorEntity>> = catalogRepository.getCreditTvShowActor(dataIdTvShow)
}