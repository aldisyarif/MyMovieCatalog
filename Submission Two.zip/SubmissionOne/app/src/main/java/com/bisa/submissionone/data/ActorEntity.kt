package com.bisa.submissionone.data

class ActorEntity(
    var imgPath: String?,
    var name: String
)