package com.bisa.submissionone.data

data class DetailCatalogEntity(
    var dataId: String,
    var imagePoster: String?,
    var title: String?,
    var tagline: String?,
    var release_date: String?,
    var genre: List<Genres>?,
    var duration: String?,
    var score: String?,
    var description: String?,
    //var listActor: ArrayList<ActorEntity>
)

data class Genres(
    var id: String,
    var name: String
)