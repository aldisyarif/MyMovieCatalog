package com.bisa.submissionone.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.bisa.submissionone.data.*
import com.bisa.submissionone.data.source.remote.RemoteDataSource
import com.bisa.submissionone.data.source.remote.response.*

class FakeCatalogRepository (private val remoteData: RemoteDataSource): CatalogDataSource{

    override fun getListMovies(): LiveData<List<CatalogEntity>> {
        val movieResult = MutableLiveData<List<CatalogEntity>>()

        remoteData.getListMovies(object : RemoteDataSource.LoadListMoviesCallback{
            override fun onListMoviesReceived(moviesResponse: List<ResultsMovieItem>) {

                val movieList = ArrayList<CatalogEntity>()

                for (response in moviesResponse){
                    val movie = CatalogEntity(
                        dataId = response.id.toString(),
                        imagePoster = response.posterPath,
                        title = response.title
                    )
                    movieList.add(movie)
                }
                movieResult.postValue(movieList)
            }

        })


        return movieResult
    }

    override fun getListTvShows(): LiveData<List<CatalogEntity>> {
        val tvShowsResult = MutableLiveData<List<CatalogEntity>>()

        remoteData.getListTvShows(object : RemoteDataSource.LoadListTvShowsCallback {
            override fun onListTvShowsReceived(tvShowsResponse: List<ResultsTvShowItem>) {

                val tvShowList = ArrayList<CatalogEntity>()
                for (response in tvShowsResponse){
                    val tvShow = CatalogEntity(
                        dataId = response.id.toString(),
                        imagePoster = response.posterPath,
                        title = response.name
                    )
                    tvShowList.add(tvShow)
                }
                tvShowsResult.postValue(tvShowList)
            }

        })

        return tvShowsResult
    }

    override fun getDetailCatalogMovie(movieId: String): LiveData<DetailCatalogEntity> {
        val detailMovieResult = MutableLiveData<DetailCatalogEntity>()

        remoteData.getDetailCatalogMovie(movieId, object : RemoteDataSource.LoadDetailMovieCatalogCallback{
            override fun onDetailMovieCatalogReceived(detailCatalogMovie: DetailCatalogMovieResponse) {

                val hour = detailCatalogMovie.runtime / 60
                val minute = detailCatalogMovie.runtime % 60
                val duration = "${hour}H ${minute}m"

                val genreList = ArrayList<Genres>()
                for (genres in detailCatalogMovie.genres){
                    val genre = Genres(
                        id = genres.id.toString(),
                        name = genres.name
                    )
                    genreList.add(genre)
                }

                val movie = DetailCatalogEntity(
                    dataId = detailCatalogMovie.id.toString(),
                    imagePoster = detailCatalogMovie.posterPath,
                    title = detailCatalogMovie.title,
                    tagline = detailCatalogMovie.tagline,
                    release_date = detailCatalogMovie.releaseDate,
                    genre =  genreList,
                    score = (detailCatalogMovie.voteAverage * 10).toString(),
                    duration = duration,
                    description = detailCatalogMovie.overview

                )
                detailMovieResult.postValue(movie)

            }

        })

        return detailMovieResult
    }

    override fun getDetailCatalogTvShow(tvId: String): LiveData<DetailCatalogEntity> {
        val detailTvResult = MutableLiveData<DetailCatalogEntity>()

        remoteData.getDetailCatalogTvShow(tvId, object : RemoteDataSource.LoadDetailTvShowCatalogCallback{
            override fun onDetailTvShowCatalogReceived(detailCatalogTv: DetailCatalogTvResponse) {

                val durationList = ArrayList<Int>()
                for (duration in detailCatalogTv.episodeRunTime!!){
                    durationList.add(duration!!)
                }

                val genreList = ArrayList<Genres>()
                for (genres in detailCatalogTv.genres!!){
                    val genre = Genres(
                        id = genres?.id.toString(),
                        name = genres?.name!!
                    )
                    genreList.add(genre)
                }

                val tvShow = DetailCatalogEntity(
                    dataId = detailCatalogTv.id.toString(),
                    imagePoster = detailCatalogTv.posterPath,
                    title = detailCatalogTv.name,
                    tagline = detailCatalogTv.tagline,
                    release_date = detailCatalogTv.firstAirDate,
                    genre = genreList,
                    score = (detailCatalogTv.voteAverage * 10).toString(),
                    duration = durationList.joinToString(","),
                    description = detailCatalogTv.overview
                )
                detailTvResult.postValue(tvShow)
            }

        })

        return detailTvResult
    }

    override fun getCreditMovieActor(movieId: String): LiveData<List<ActorEntity>> {
        val actorsResult = MutableLiveData<List<ActorEntity>>()

        remoteData.getCreditMovieActor(movieId, object : RemoteDataSource.LoadCreditMovieActorCallback{
            override fun onCreditMovieActorReceived(creditMovieActorResponse: List<CastMovieItem>) {
                val actorList = ArrayList<ActorEntity>()

                for (response in creditMovieActorResponse){
                    val actor = ActorEntity(
                        imgPath = response.profilePath ?: " ",
                        name = response.name
                    )
                    actorList.add(actor)
                }
                actorsResult.postValue(actorList)
            }
        })

        return actorsResult
    }

    override fun getCreditTvShowActor(tvId: String): LiveData<List<ActorEntity>> {
        val actorsResult = MutableLiveData<List<ActorEntity>>()

        remoteData.getCreditTvShowActor(tvId, object : RemoteDataSource.LoadCreditTvShowActorCallback{
            override fun onCreditTvShowActorReceived(creditTvActorResponse: List<CastTvItem>) {
                val actorList = ArrayList<ActorEntity>()

                for (response in creditTvActorResponse){
                    val actor = ActorEntity(
                        imgPath = response.profilePath ?: " ",
                        name = response.name!!
                    )
                    actorList.add(actor)
                }
                actorsResult.postValue(actorList)
            }

        })

        return actorsResult
    }


}