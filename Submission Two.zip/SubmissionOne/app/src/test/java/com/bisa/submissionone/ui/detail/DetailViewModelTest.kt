package com.bisa.submissionone.ui.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.bisa.submissionone.data.ActorEntity
import com.bisa.submissionone.data.DetailCatalogEntity
import com.bisa.submissionone.data.source.CatalogRepository
import com.bisa.submissionone.utils.DataDummy
import com.nhaarman.mockitokotlin2.verify
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {

    private lateinit var viewModel: DetailViewModel


    private val dummyDetailMovie = DataDummy.generateDetailMovie()
    private val dataIdMovie = dummyDetailMovie.dataId

    private val dummyDetailTv = DataDummy.generateDetailTvShow()
    private val dataIdTv = dummyDetailTv.dataId

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogRepository: CatalogRepository

    @Mock
    private lateinit var observer: Observer<DetailCatalogEntity>
    @Mock
    private lateinit var observerActor: Observer<List<ActorEntity>>

    @Before
    fun setUp() {
        viewModel = DetailViewModel(catalogRepository)

        viewModel.setSelectedMovie(dataIdMovie)
        viewModel.setSelectedTvShow(dataIdTv)
    }

    @Test
    fun getContentTvShow() {

        val tv = MutableLiveData<DetailCatalogEntity>()
        tv.value = dummyDetailTv

        `when`(catalogRepository.getDetailCatalogTvShow(dataIdTv)).thenReturn(tv)
        val detailTvEntity = viewModel.getContentTvShow().value as DetailCatalogEntity

        verify<CatalogRepository>(catalogRepository).getDetailCatalogTvShow(dataIdTv)

        assertNotNull(detailTvEntity)
        assertEquals(dummyDetailTv.dataId, detailTvEntity.dataId)
        assertEquals(dummyDetailTv.imagePoster, detailTvEntity.imagePoster)
        assertEquals(dummyDetailTv.tagline, detailTvEntity.tagline)
        assertEquals(dummyDetailTv.title, detailTvEntity.title)
        assertEquals(dummyDetailTv.genre?.size, detailTvEntity.genre?.size)
        assertEquals(dummyDetailTv.release_date, detailTvEntity.release_date)
        assertEquals(dummyDetailTv.duration, detailTvEntity.duration)
        assertEquals(dummyDetailTv.score, detailTvEntity.score)
        assertEquals(dummyDetailTv.description, detailTvEntity.description)

    }

    @Test
    fun getContentMovie() {

        val movie = MutableLiveData<DetailCatalogEntity>()
        movie.value = dummyDetailMovie

        `when`(catalogRepository.getDetailCatalogMovie(dataIdMovie)).thenReturn(movie)
        val detailMovieEntity = viewModel.getContentMovie().value as DetailCatalogEntity

        verify<CatalogRepository>(catalogRepository).getDetailCatalogMovie(dataIdMovie)

        assertNotNull(detailMovieEntity)
        assertEquals(dummyDetailMovie.dataId, detailMovieEntity.dataId)
        assertEquals(dummyDetailMovie.imagePoster, detailMovieEntity.imagePoster)
        assertEquals(dummyDetailMovie.tagline, detailMovieEntity.tagline)
        assertEquals(dummyDetailMovie.title, detailMovieEntity.title)
        assertEquals(dummyDetailMovie.genre?.size, detailMovieEntity.genre?.size)
        assertEquals(dummyDetailMovie.release_date, detailMovieEntity.release_date)
        assertEquals(dummyDetailMovie.duration, detailMovieEntity.duration)
        assertEquals(dummyDetailMovie.score, detailMovieEntity.score)
        assertEquals(dummyDetailMovie.description, detailMovieEntity.description)

        viewModel.getContentMovie().observeForever(observer)
        verify(observer).onChanged(dummyDetailMovie)

    }

    @Test
    fun getActorMovie(){
        val dummyActorMovie = DataDummy.generateActorMovie()
        val actor = MutableLiveData<List<ActorEntity>>()

        actor.value = dummyActorMovie

        `when`(catalogRepository.getCreditMovieActor(dataIdMovie)).thenReturn(actor)
        val actorEntities = viewModel.getActorMovie().value
        verify<CatalogRepository>(catalogRepository).getCreditMovieActor(dataIdMovie)

        assertNotNull(actorEntities)
        assertEquals(5, actorEntities?.size)

        viewModel.getActorMovie().observeForever(observerActor)
        verify(observerActor).onChanged(dummyActorMovie)
    }

    @Test
    fun getActorTvShow(){
        val dummyActorTv = DataDummy.generateActorTvShow()
        val actor = MutableLiveData<List<ActorEntity>>()

        actor.value = dummyActorTv

        `when`(catalogRepository.getCreditTvShowActor(dataIdTv)).thenReturn(actor)
        val actorEntities = viewModel.getActorTvShow().value
        verify<CatalogRepository>(catalogRepository).getCreditTvShowActor(dataIdTv)

        assertNotNull(actorEntities)
        assertEquals(5, actorEntities?.size)

        viewModel.getActorTvShow().observeForever(observerActor)
        verify(observerActor).onChanged(dummyActorTv)
    }
}