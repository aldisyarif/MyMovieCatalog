package com.bisa.submissionone.data.source

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.bisa.submissionone.data.source.remote.RemoteDataSource
import com.bisa.submissionone.utils.DataDummy
import com.bisa.submissionone.utils.LiveDataTestUtils
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.doAnswer
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.verify
import junit.framework.Assert.assertEquals
import junit.framework.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test


import org.mockito.Mockito.mock

class CatalogRepositoryTest {

    private val remote = mock(RemoteDataSource::class.java)
    private val catalogRepository = FakeCatalogRepository(remote)

    private val movieResponse = DataDummy.generateRemoteListMovie()
    private val movieId = movieResponse[1].id.toString()
    private val tvResponse = DataDummy.generateRemoteListTvShow()
    private val tvId = tvResponse[0].id.toString()

    private val detailMovieResponse = DataDummy.generateRemoteDetailMovie()
    private val detailTvResponse = DataDummy.generateRemoteDetailTvShow()

    private val actorMovieResponse = DataDummy.generateRemoteActorMovie()
    private val actorTvResponse = DataDummy.generateRemoteActorTvShow()

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Test
    fun getListMovies() {
        doAnswer{ invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadListMoviesCallback)
                    .onListMoviesReceived(movieResponse)
            null
        }.`when`(remote).getListMovies(any())

        val movieEntities = LiveDataTestUtils.getValue(catalogRepository.getListMovies())
        verify(remote).getListMovies(any())

        assertNotNull(movieEntities)
        assertEquals(movieResponse.size.toLong(), movieEntities.size.toLong())
    }

    @Test
    fun getListTvShows() {
        doAnswer { invocation ->
            (invocation.arguments[0] as RemoteDataSource.LoadListTvShowsCallback)
                    .onListTvShowsReceived(tvResponse)
            null
        }.`when`(remote).getListTvShows(any())

        val tvEntities = LiveDataTestUtils.getValue(catalogRepository.getListTvShows())
        verify(remote).getListTvShows(any())

        assertNotNull(tvEntities)
        assertEquals(tvResponse.size.toLong(), tvEntities.size.toLong())
    }

    @Test
    fun getDetailCatalogMovie() {
        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadDetailMovieCatalogCallback)
                    .onDetailMovieCatalogReceived(detailMovieResponse)
            null
        }.`when`(remote).getDetailCatalogMovie(eq(movieId), any())

        val detailMovieEntities = LiveDataTestUtils.getValue(catalogRepository.getDetailCatalogMovie(movieId))
        verify(remote).getDetailCatalogMovie(eq(movieId), any())

        assertNotNull(detailMovieEntities)
        assertNotNull(detailMovieEntities.title)
        assertEquals(detailMovieResponse.title, detailMovieEntities.title)
    }

    @Test
    fun getDetailCatalogTvShow() {
        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadDetailTvShowCatalogCallback)
                    .onDetailTvShowCatalogReceived(detailTvResponse)
            null
        }.`when`(remote).getDetailCatalogTvShow(eq(tvId), any())

        val detailTvEntities = LiveDataTestUtils.getValue(catalogRepository.getDetailCatalogTvShow(tvId))
        verify(remote).getDetailCatalogTvShow(eq(tvId), any())

        assertNotNull(detailTvEntities)
        assertNotNull(detailTvEntities.title)
        assertEquals(detailTvResponse.name, detailTvEntities.title)
    }

    @Test
    fun getCreditMovieActor() {
        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadCreditMovieActorCallback)
                    .onCreditMovieActorReceived(actorMovieResponse)
            null
        }.`when`(remote).getCreditMovieActor(eq(movieId), any())

        val movieActorEntities = LiveDataTestUtils.getValue(catalogRepository.getCreditMovieActor(movieId))
        verify(remote).getCreditMovieActor(eq(movieId), any())

        assertNotNull(movieActorEntities)
        assertEquals(actorMovieResponse.size.toLong(), movieActorEntities.size.toLong())

    }

    @Test
    fun getCreditTvShowActor() {
        doAnswer { invocation ->
            (invocation.arguments[1] as RemoteDataSource.LoadCreditTvShowActorCallback)
                    .onCreditTvShowActorReceived(actorTvResponse)
            null
        }.`when`(remote).getCreditTvShowActor(eq(tvId), any())

        val tvActorEntities = LiveDataTestUtils.getValue(catalogRepository.getCreditTvShowActor(tvId))
        verify(remote).getCreditTvShowActor(eq(tvId), any())

        assertNotNull(tvActorEntities)
        assertEquals(actorTvResponse.size.toLong(), tvActorEntities.size.toLong())
    }
}